﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/***********************************************************
 * 
 * Copyright 2020 Nicolaas Schuddeboom, all rights reserved.
 * 
 **********************************************************/

namespace MTG_calculator
{
    static public class Program
    {
        #region Variables
        static int[] cardsInSet;
        static int[] wildcardRouletTimer; // The timer information for wildcards guaranteed per pack
        static int[] randomWildcardRouletTimer; // The timer information for wildcards randomly gained
        static double[] cardsInPacks; // The cards we gained from packs. Starts at 1 pack and is increased later
        static double[] openedWildcards;
        static string[] rarityNames = new string[] { "common", "uncommon", "rare", "mythic rare" };

        static int[,] cardsToOpen; // For a deck per set
        static int[,] cardsForcedToCraft;
        static double[,] cardCopiesOwned; // Only an average

        static int packsAlreadyOpened;
        static public List<PacksForDecksDictionary> packsForDecks = new List<PacksForDecksDictionary>(); // See class comment
        static public List<PacksForSetsDictionary> packsPerSets = new List<PacksForSetsDictionary>(); // See class comment
        static int packsToOpen;
        static int maxDuplicates; // 4
        static int rarityAmount; // 4
        static int craftGoal; // Wildcards per rarity
        static double craftProgress; // Wildcards per rarity
        static string set;
        static string deck;
        static double vaultPoints = 0; // MTG mechanic

        // find reprints in Scryfall.com
        // (set:M21 (in:iko or in:thb or in:eld or in:m20 or in:war or in:rna or in:grn)) or (in:iko (in:thb or in:eld or in:m20 or in:war or in:rna or in:grn)) or (in:thb (in:eld or in:m20 or in:war or in:rna or in:grn)) or (in:eld (in:m20 or in:war or in:rna or in:grn)) or (in:m20 (in:war or in:rna or in:grn)) or (in:m20 (in:war or in:rna or in:grn)) or (in:war (in:rna or in:grn)) or (in:rna in:GRN)
        static string[] setMemory = new string[] { "M21", "IKO", "THB", "ELD", "M20", "WAR", "RNA", "GRN" };

        // Here the names of the decks are inserted. If you want to skip a deck in the calculation, but feel the need to use it later, you can comment it here.
        // Data will be kept, but it will not be taken into the calculations.
        static List<string> deckMemory = new List<string> {
            "Boros Tour de France",
            "Izzet Drakes",
            "Blue Mill"
        };

        // The difference between the two following dictionaries is that packsPerSetsDictionary remembers for EACH SET how many packs were opened for AN ENTIRE DECK 
        
        // while packsForDecksDictionary is a bit more complicated. This dictionary only remembers how many cards for A SINGLE SET it needs to open (Value) and with
        // how many packs this should be TESTED with.

        // PacksForSetsDictionary is meant to remember info while PacksForDecksDictionary is meant to be tested with (in the case of ordering decks from cheapest to most
        // expensive)

        // A variable that is used to simulate a dictionary with duplicate keys
        public class PacksForSetsDictionary
        {
            public string key;
            public int[] value;

            public PacksForSetsDictionary(string key, int[] value)
            {
                this.key = key;
                this.value = value;
            }

            public string Key
            {
                get
                {
                    return key;
                }
            }
            public int[] Value
            {
                get
                {
                    return value;
                }
            }
        }

        // A variable that is used to simulate a dictionary with duplicate keys
        public class PacksForDecksDictionary
        {
            public int key;
            public int[,] value;
            public int[,] forcedValue;

            public PacksForDecksDictionary(int key, int[,] value, int[,] forcedValue)
            {
                this.key = key;
                this.value = value;
                this.forcedValue = forcedValue;
            }

            public int Key
            {
                get
                {
                    return key;
                }
            }
            public int[,] Value
            {
                get
                {
                    return value;
                }
            }
            public int[,] ForcedValue
            {
                get
                {
                    return forcedValue;
                }
            }
        }
        #endregion

        // Starting point
        static void Main(string[] args)
        {
            // Check if the client wants to check for the cheapest decks
            Console.Write("Do you want to figure out the cheapest set? Click y: ");
            bool checkAllDecks = Console.ReadKey().Key == ConsoleKey.Y;

            Console.WriteLine();

            // If we only want to check how many cards we get from packs, do the following.
            if (!checkAllDecks)
            {
                // Ask for set
                Console.Write("What set: ");
                set = Console.ReadLine();

                // Ask for packs
                Console.Write("How many packs to open: ");
                packsToOpen = Convert.ToInt32(Console.ReadLine());

                // Here, decks can be inserted with a pack value to also add the average crafted cards into the calculation per crafted deck. 
                // Recommended to figure out with CalculateCheapestDecks what these values are and insert them here. Be careful to not respond with a lower number in the 
                // question above, as weird results end up happening so comment again if this problem occurs. Sort these from cheapest to most expensive.
                #region Add average crafted cards per crafted deck
                deck = "Template";
                AddDeck(0);

                switch (set)
                {
                    case "M21":
                        #region M21
                        //deck = "Boros Tour de France";
                        //AddDeck(0);

                        //deck = "Blue Mill";
                        //AddDeck(0);
                        #endregion
                        break;
                    case "IKO":
                        #region IKO
                        //deck = "Boros Tour de France";
                        //AddDeck(40);

                        //deck = "Blue Mill";
                        //AddDeck(40);
                        #endregion
                        break;
                    case "THB":
                        #region THB
                        //deck = "Boros Tour de France";
                        //AddDeck(0);

                        //deck = "Blue Mill";
                        //AddDeck(0);
                        #endregion
                        break;
                    case "ELD":
                        #region ELD
                        //deck = "Boros Tour de France";
                        //AddDeck(0);

                        //deck = "Blue Mill";
                        //AddDeck(31);
                        #endregion
                        break;
                    case "M20":
                        #region M20
                        //deck = "Boros Tour de France";
                        //AddDeck(0);

                        //deck = "Blue Mill";
                        //AddDeck(0);
                        #endregion
                        break;
                    case "WAR":
                        #region WAR
                        //deck = "Boros Tour de France";
                        //AddDeck(0);

                        //deck = "Blue Mill";
                        //AddDeck(8);
                        #endregion
                        break;
                    case "RNA":
                        #region RNA
                        //deck = "Boros Tour de France";
                        //AddDeck(0);

                        //deck = "Blue Mill";
                        //AddDeck(12);
                        #endregion
                        break;
                    case "GRN":
                        #region GRN
                        //deck = "Boros Tour de France";
                        //AddDeck(0);

                        //deck = "Blue Mill";
                        //AddDeck(21);
                        #endregion
                        break;
                    default:
                        break;
                }
                #endregion

                // Get if you can craft the last deck in the above information
                Console.WriteLine("Craftable? " + GetIfCraftable());

                // Get collection results
                GetCollectionResults();
            }
            else
            {
                // Calculate cheapest decks
                CalculateCheapestDecks();
            }
            Console.ReadKey();
        }

        // SUMMARY: Get a deck and how many cards are needed for each rarity and duplicate amount. Then, with the packs given to us, add this to a dictionary
        // This part asks for really specific values (how many cards different cards? How many duplicates each?) which resulted in this somewhat confusing information method.
        // However, using this method makes the calculator very accurate, as with this specific information, it can take things like crafted cards into account.
        static void AddDeck(int packs)
        {
            // Setup
            #region Initialize
            // This is to make sure there will be no error, as we can't return null
            cardsToOpen = new int[,]
            {
                { 0, 0, 0, 0 },
                { 0, 0, 0, 0 },
                { 0, 0, 0, 0 },
                { 0, 0, 0, 0 }
            };

            // The same as cardsToOpen, but these have to be crafted
            cardsForcedToCraft = new int[,]
            {
                { 0, 0, 0, 0 },
                { 0, 0, 0, 0 },
                { 0, 0, 0, 0 },
                { 0, 0, 0, 0 }
            };
            #endregion

            // Template
            #region Template
            if (deck == "Template")
            {
                if (set == "M21")
                {
                    cardsToOpen = new int[,]
                    {
                        { 0, 0, 0, 0 },
                        { 0, 0, 0, 0 },
                        { 0, 0, 0, 0 },
                        { 0, 0, 0, 0 }
                    };
                }
                if (set == "IKO")
                {
                    cardsToOpen = new int[,]
                    {
                        { 0, 0, 0, 0 },
                        { 0, 0, 0, 0 },
                        { 0, 0, 0, 0 },
                        { 0, 0, 0, 0 }
                    };
                }
                if (set == "THB")
                {
                    cardsToOpen = new int[,]
                    {
                        { 0, 0, 0, 0 },
                        { 0, 0, 0, 0 },
                        { 0, 0, 0, 0 },
                        { 0, 0, 0, 0 }
                    };
                }
                if (set == "ELD")
                {
                    cardsToOpen = new int[,]
                     {
                        { 0, 0, 0, 0 },
                        { 0, 0, 0, 0 },
                        { 0, 0, 0, 0 },
                        { 0, 0, 0, 0 }
                     };

                }
                if (set == "M20")
                {
                    cardsToOpen = new int[,]
                    {
                        { 0, 0, 0, 0 },
                        { 0, 0, 0, 0 },
                        { 0, 0, 0, 0 },
                        { 0, 0, 0, 0 }
                    };
                }
                if (set == "WAR")
                {
                    cardsToOpen = new int[,]
                    {
                        { 0, 0, 0, 0 },
                        { 0, 0, 0, 0 },
                        { 0, 0, 0, 0 },
                        { 0, 0, 0, 0 }
                    };

                }
                if (set == "RNA")
                {
                    cardsToOpen = new int[,]
                    {
                        { 0, 0, 0, 0 },
                        { 0, 0, 0, 0 },
                        { 0, 0, 0, 0 },
                        { 0, 0, 0, 0 }
                    };

                }
                if (set == "GRN")
                {
                    cardsToOpen = new int[,]
                    {
                        { 0, 0, 0, 0 },
                        { 0, 0, 0, 0 },
                        { 0, 0, 0, 0 },
                        { 0, 0, 0, 0 }
                    };

                }

            }
            #endregion

            // Decks for standard
            #region Standard
            #region Boros Tour de France
            if (deck == "Boros Tour de France")
            {
                if (set == "IKO")
                {
                    cardsToOpen = new int[,]
                    {
                        { 6, 6, 6, 6 },
                        { 5, 4, 4, 4 },
                        { 1, 0, 0, 0 },
                        { 0, 0, 0, 0 }
                    };
                }
                if (set == "THB")
                {
                    cardsToOpen = new int[,]
                    {
                        { 0, 0, 0, 0 },
                        { 0, 0, 0, 0 },
                        { 0, 0, 0, 0 },
                        { 0, 0, 0, 0 }
                    };
                }
                if (set == "ELD")
                {
                    cardsToOpen = new int[,]
                     {
                        { 0, 0, 0, 0 },
                        { 0, 0, 0, 0 },
                        { 0, 0, 0, 0 },
                        { 0, 0, 0, 0 }
                     };

                }
                if (set == "M20")
                {
                    cardsToOpen = new int[,]
                    {
                        { 0, 0, 0, 0 },
                        { 0, 0, 0, 0 },
                        { 0, 0, 0, 0 },
                        { 0, 0, 0, 0 }
                    };
                }
                if (set == "WAR")
                {
                    cardsToOpen = new int[,]
                    {
                        { 0, 0, 0, 0 },
                        { 0, 0, 0, 0 },
                        { 0, 0, 0, 0 },
                        { 0, 0, 0, 0 }
                    };

                }
                if (set == "RNA")
                {
                    cardsToOpen = new int[,]
                    {
                        { 0, 0, 0, 0 },
                        { 0, 0, 0, 0 },
                        { 0, 0, 0, 0 },
                        { 0, 0, 0, 0 }
                    };

                }
                if (set == "GRN")
                {
                    cardsToOpen = new int[,]
                    {
                        { 0, 0, 0, 0 },
                        { 0, 0, 0, 0 },
                        { 0, 0, 0, 0 },
                        { 0, 0, 0, 0 }
                    };

                }

            }
            #endregion

            #region Izzet Drakes
            if (deck == "Izzet Drakes")
            {
                if (set == "THB")
                {
                    cardsToOpen = new int[,]
                    {
                        { 0, 0, 0, 0 },
                        { 0, 0, 0, 0 },
                        { 0, 0, 0, 0 },
                        { 0, 0, 0, 0 }
                    };
                }
                if (set == "ELD")
                {
                    cardsToOpen = new int[,]
                    {
                        { 2, 2, 2, 2 },
                        { 1, 1, 1, 1 },
                        { 1, 1, 1, 1 },
                        { 1, 1, 0, 0 }
                    };
                }
                if (set == "M20")
                {
                    cardsToOpen = new int[,]
                    {
                        { 1, 1, 1, 1 },
                        { 0, 0, 0, 0 },
                        { 1, 1, 1, 1 },
                        { 0, 0, 0, 0 },
                    };
                }
                if (set == "WAR")
                {
                    cardsToOpen = new int[,]
                    {
                        { 0, 0, 0, 0 },
                        { 0, 0, 0, 0 },
                        { 0, 0, 0, 0 },
                        { 0, 0, 0, 0 }
                    };
                }
                if (set == "RNA")
                {
                    cardsToOpen = new int[,]
                    {
                        { 0, 0, 0, 0 },
                        { 0, 0, 0, 0 },
                        { 0, 0, 0, 0 },
                        { 0, 0, 0, 0 }
                    };
                }
                if (set == "GRN")
                {
                    cardsToOpen = new int[,]
                    {
                        { 2, 2, 2, 1 },
                        { 3, 3, 2, 1 },
                        { 1, 1, 1, 1 },
                        { 0, 0, 0, 0 }
                    };
                }

            }
            #endregion

            #region Blue Mill
            if (deck == "Blue Mill")
            {
                if (set == "THB")
                {
                    cardsToOpen = new int[,]
                    {
                        { 0, 0, 0, 0 },
                        { 0, 0, 0, 0 },
                        { 0, 0, 0, 0 },
                        { 0, 0, 0, 0 }
                    };

                }
                if (set == "ELD")
                {
                    cardsToOpen = new int[,]
                    {
                        { 4, 4, 4, 4 },
                        { 2, 2, 2, 1 },
                        { 2, 1, 1, 1 },
                        { 0, 0, 0, 0 }
                    };

                }
                if (set == "M20")
                {
                    cardsToOpen = new int[,]
                    {
                        { 0, 0, 0, 0 },
                        { 0, 0, 0, 0 },
                        { 0, 0, 0, 0 },
                        { 0, 0, 0, 0 }
                    };

                }
                if (set == "WAR")
                {
                    cardsToOpen = new int[,]
                    {
                        { 1, 1, 1, 0 },
                        { 0, 0, 0, 0 },
                        { 0, 0, 0, 0 },
                        { 0, 0, 0, 0 }
                    };

                }
                if (set == "RNA")
                {
                    cardsToOpen = new int[,]
                    {
                        { 1, 1, 1, 1 },
                        { 1, 1, 1, 1 },
                        { 0, 0, 0, 0 },
                        { 0, 0, 0, 0 }
                    };

                }
                if (set == "GRN")
                {
                    cardsToOpen = new int[,]
                    {
                        { 0, 0, 0, 0 },
                        { 0, 0, 0, 0 },
                        { 1, 1, 1, 1 },
                        { 0, 0, 0, 0 }
                    };

                }

            }
            #endregion
            #endregion

            // How many packs need to be opened to get all cards of the rarity
            // The * means that it is only an average amount as these rarities do not have the duplicate protection rule
            #region All rarities
            // 98* packs
            #region All Common
            if (deck == "All Common")
            {
                cardsToOpen = new int[,]
                {
                        { 101, 101, 101, 101 },
                        { 0, 0, 0, 0 },
                        { 0, 0, 0, 0 },
                        { 0, 0, 0, 0 }
                };
            }
            #endregion

            // 158* packs
            #region All Uncommon
            if (deck == "All Uncommon")
            {
                cardsToOpen = new int[,]
                {
                        { 0, 0, 0, 0 },
                        { 80, 80, 80, 80},
                        { 0, 0, 0, 0 },
                        { 0, 0, 0, 0 }
                };
            }
            #endregion

            // 215 packs
            #region All Rares
            if (deck == "All Rares")
            {
                cardsToOpen = new int[,]
                {
                        { 0, 0, 0, 0 },
                        { 0, 0, 0, 0 },
                        { 53, 53, 53, 53 },
                        { 0, 0, 0, 0 }
                };
            }
            #endregion

            // 321 packs
            #region All Mythic
            if (deck == "All Mythics")
            {
                cardsToOpen = new int[,]
                {
                        { 0, 0, 0, 0 },
                        { 0, 0, 0, 0 },
                        { 0, 0, 0, 0 },
                        { 15, 15, 15, 15 }
                };
            }
            #endregion
            #endregion

            // Add information
            packsForDecks.Add(new PacksForDecksDictionary(packs, (int[,])cardsToOpen.Clone(), (int[,])cardsForcedToCraft.Clone()));
        }

        #region Collection management
        // Get how many cards we've gotten from our packs
        static void GetCollectionResults()
        {
            // Declare. This variable is the total amount of cards we've opened per rarity
            double totalCardsPerRarity;

            // Go through rarities
            for (int i = 0; i < cardCopiesOwned.GetLength(0); i++)
            {
                // Total opened cards per rarity
                totalCardsPerRarity = 0;

                // Go through amount of duplicates
                for (int j = 0; j < cardCopiesOwned.GetLength(1); j++)
                {
                    // Add to total and print "Rarity/Cards gotten/Cards in set"
                    totalCardsPerRarity += cardCopiesOwned[i, j];
                    Console.WriteLine("Of the rarity " + rarityNames[i] + ", you have opened " + (j + 1) + " duplicates a total of " + cardCopiesOwned[i, j] + " times out of " + cardsInSet[i] + " cards.");
                }
                // Print "Total cards opened for rarity/Opened wildcards"
                Console.WriteLine("TOTAL: " + totalCardsPerRarity);
                Console.WriteLine("Wild cards: " + openedWildcards[i]);

                Console.WriteLine();
            }

            // Print vault points
            Console.WriteLine("Vault Points: " + vaultPoints);
        }

        static void InitializeVariables()
        {
            #region Initialize
            // MTG amount of rarities and duplicate limit
            maxDuplicates = 4;
            rarityAmount = 4;

            // Wildcard chances per pack (rather than filling 20% or 1/5 we fill in 5 to make it easier later)
            randomWildcardRouletTimer = new int[] { 3, 5, 30, 30 };

            // Guaranteed wildcards after specific amount of packs (not chance, always every time these numbers are reached. Commons [0] aren't given away this method)
            wildcardRouletTimer = new int[] { 0, 6, 6, 30 };

            // Cards in a pack reset
            cardsInPacks = new double[] { 5, 2, 0.875f, 0.125f };

            // Opened wildcards
            openedWildcards = new double[4];

            // Cards opened
            cardCopiesOwned = new double[rarityAmount, maxDuplicates];

            // This variable is used to calculate the cheapest deck.
            packsAlreadyOpened = 0;

            // Vualt points
            vaultPoints = 0;

            // Set the values for how many cards are in the set
            cardsInSet = new int[] { 101, 80, 53, 15 };
            #endregion
        }

        static void AddCardsToCollection(int packsGoingToOpen, bool restart)
        {
            // Reset variables if we start a new collection
            if (restart)
            {
                InitializeVariables();
            }

            // PacksGoingToOpen is at the current moment a value which is the total packs opened. By substract we get a value what the name sugests
            // (Because of the way the code is made, it's best to do it this way)
            // (It is also needed to make this a different variable from packsToOpen because that variable constantly changes in the cheapest deck calculation and substracting turns this possibly into an infinite loop)
            packsGoingToOpen -= packsAlreadyOpened;

            // Cards in a pack reset
            cardsInPacks = new double[] { 5, 2, 0.875f, 0.125f };

            // Multiply the cards in the pack with the packs we are going to open.
            for (int i = 0; i < cardsInPacks.Length; i++)
            {
                cardsInPacks[i] *= packsGoingToOpen;
            }

            // Go through rarities
            for (int i = 0; i < openedWildcards.Length; i++)
            {
                // Get opened wildcards from the packs we are going to open
                openedWildcards[i] = packsGoingToOpen / (double)randomWildcardRouletTimer[i];

                // Then, depending on rarity, substract the cards in the pack (because wildcards replace a card in a pack)
                if (i <= 1)
                {
                    cardsInPacks[i] -= openedWildcards[i];
                }
                else
                {
                    // With rare and mythic rare, this works a little different. BOTH have a 1 in 30 chance to be replaced with a wildcard, but share the same card slot.
                    // Since both share the same slot, deviding by 30 will result in more rare wildcards as the calculator will open more of these and thus devide a higher 
                    // number than the mythic rares
                    // To solve this, we must multiply the cards we've opened to give both an equal chance and devide that number.
                    // The numbers, not looking at scale, are ( (chance on getting rarity card - chance on getting rarity WILDcard) / total chance of both )
                    // To prove that this works, you can start the program, type any set and open 1 pack. Both rarities have 0.033 wildcard, 1/30 and thus get an equal amount
                    if (i == 2)
                    {
                        cardsInPacks[i] = (packsGoingToOpen) * 196.0 / 240.0;
                    }
                    else
                    {
                        cardsInPacks[i] = (packsGoingToOpen) * 28.0 / 240.0;
                    }
                }

                // Then get the remaining wildcards
                openedWildcards[i] += packsAlreadyOpened / (double)randomWildcardRouletTimer[i];

                // Then get the wildcards from the roulet timer
                if (wildcardRouletTimer[i] != 0)
                {
                    openedWildcards[i] += (packsGoingToOpen + packsAlreadyOpened) / wildcardRouletTimer[i];
                }
            }

            // And substract some rares depending on how many mythics we opened with the roulet
            openedWildcards[2] -= (packsGoingToOpen + packsAlreadyOpened) / wildcardRouletTimer[3];

            // ADD CARDS TO THE COLLECTION
            for (int i = 0; i < cardsInPacks.Length; i++)
            {
                for (int j = 1; j <= cardsInPacks[i]; j++)
                {
                    AddCard(i, 1);
                }
                AddCard(i, cardsInPacks[i] % 1);
            }

            // Get vaultpoints and add some wildcards
            openedWildcards[1] += vaultPoints / 1000 * 3;
            openedWildcards[2] += vaultPoints / 1000 * 2;
            openedWildcards[3] += vaultPoints / 1000;

            // Set packsAlreadyOpened to the right value
            packsAlreadyOpened += packsGoingToOpen;
        }
        #endregion

        #region Calculation management
        static bool GetIfCraftable()
        {
            // Setup
            double[] wildcardUsed = new double[4];
            double[,] specificWildcardUsed = new double[4, 4];
            double wildcardsJustUsed;

            // Go through all the premade decks
            for (int a = 0; a < packsForDecks.Count; a++)
            {
                #region Not the last deck
                // Checks if we are at the last deck or not
                if (a < packsForDecks.Count - 1)
                {
                    // Add cards to the collection or start it if we're at the first deck
                    AddCardsToCollection(packsForDecks[a].Key, a == 0);

                    // Go through rarities
                    for (int i = 0; i < cardCopiesOwned.GetLength(0); i++)
                    {
                        // Go through duplicates
                        for (int j = 0; j < cardCopiesOwned.GetLength(1); j++)
                        {
                            // Forced cards to craft
                            int forcedToCraft = 0;

                            // Get data
                            forcedToCraft = packsForDecks[a].ForcedValue[i, j];

                            // This value is the amount of wildcards we're going to use. 
                            // It gets the percentage of the set we don't have. This is our chances we didn't open a card we wanted and we multiply this with the amount of cards we wanted to get.
                            // This is the value we didn't open and needed wildcards to use on.
                            wildcardsJustUsed = (1 - cardCopiesOwned[i, j] / cardsInSet[i]) * packsForDecks[a].Value[i, j];

                            // Wildcards used per rarity. ForcedToCraft is only used here as forcedToCraft cards aren't in the cardCopiesOwned and
                            // specificWildcardUsed interacts with that variable. These cards will typicaly be basic land cards which you can't open in MTG Arena packs
                            wildcardUsed[i] += wildcardsJustUsed + forcedToCraft;

                            // Wildcards used per rarity and duplicate amount.
                            specificWildcardUsed[i, j] += wildcardsJustUsed;

                            // Add this wildcard to the collection (since we crafted a card using it).
                            cardCopiesOwned[i, j] += wildcardsJustUsed;
                        }
                    }
                }
                #endregion

                #region Last deck
                else
                {
                    // Add cards to the collection or start it if we're at the first deck (first variable is different from the previous function)
                    AddCardsToCollection(packsToOpen, a == 0);

                    // Go through rarities
                    for (int i = 0; i < cardCopiesOwned.GetLength(0); i++)
                    {
                        // Reset craft goal and progress
                        craftGoal = 0;
                        craftProgress = 0;

                        // Go through duplicates
                        for (int j = 0; j < cardCopiesOwned.GetLength(1); j++)
                        {
                            // Add all cards needed for the deck (with the respected rarity) to the craft goal.
                            int ForcedToCraft = 0;

                            ForcedToCraft = packsForDecks[a].ForcedValue[i, j];

                            craftGoal += cardsToOpen[i, j] + ForcedToCraft;

                            // Calculate the craft progress which is the percentage of the amount of cards we opened out of the set that aren't used wildcards (as those are removed hard coded/manually)
                            // This amount is then multiplied by the amount of cards we want to open
                            craftProgress += (cardCopiesOwned[i, j] - specificWildcardUsed[i, j]) / (cardsInSet[i] - specificWildcardUsed[i, j]) * cardsToOpen[i, j];
                        }

                        // Add the unused wildcards to the progress
                        craftProgress += openedWildcards[i] - wildcardUsed[i];

                        // If the progress is lower than the goal, we can't craft the deck
                        if (craftProgress < craftGoal)
                        {
                            return false;
                        }
                    }

                }
                #endregion
            }
            // If we reached the end, the deck is craftable
            return true;
        }

        static void CalculateCheapestDecks()
        {
            // Setup. The difference between the two following dictionaries is that packsPerSetsy remembers for EACH SET how many packs were opened for AN ENTIRE DECK 

            // while packsForDecks is a bit more complicated. This dictionary only remembers how many cards for A SINGLE SET it needs to open (Value) and with
            // how many packs this should be TESTED with.

            // PacksForSets is meant to remember info while PacksForDecks is meant to be tested with (in the case of ordering decks from cheapest to most
            // expensive)
            packsPerSets = new List<PacksForSetsDictionary>();
            packsForDecks = new List<PacksForDecksDictionary>();

            // packsOpenedForCurrentDeck remembers the total pack cost of a deck, not per set.
            // packsOpenedForAllDecks remembers the packs opened per set.
            int[] packsOpenedForCurrentDeck;
            int[,] packsOpenedForAllDecks;

            // As the name says
            int cheapestAmountOfPacks;
            int cheapestIndex;

            // Used when we know the cheapest deck and to feed info to packsPerSets.
            int[] packsOpenedForCheapestDeck;

            // Used to know if there is a tie
            bool danger;

            // Run the code until all the premade decks are categorized
            while (deckMemory.Count > 0)
            {
                // Setup
                packsOpenedForCurrentDeck = new int[deckMemory.Count];
                packsOpenedForAllDecks = new int[deckMemory.Count, setMemory.Length];
                packsOpenedForCheapestDeck = new int[setMemory.Length];
                danger = false;

                // Let's hope we never have to open 4095 packs
                cheapestAmountOfPacks = 4095;

                // -1 since we can't have a negative array value
                cheapestIndex = -1;

                // Go through the premade decks we've made
                for (int i = 0; i < deckMemory.Count; i++)
                {
                    // Go through the sets
                    for (int j = 0; j < setMemory.Length; j++)
                    {
                        // Set set variable and reset other variables
                        set = setMemory[j];
                        InitializeVariables();

                        // Reset deck list we've already crafted
                        packsForDecks = new List<PacksForDecksDictionary>();

                        // Add the decks to the packsForDeckList
                        for (int k = 0; k < packsPerSets.Count; k++)
                        {
                            deck = packsPerSets[k].Key;

                            AddDeck(packsPerSets[k].Value[j]);
                        }

                        // Get deck
                        deck = deckMemory[i];

                        // Zero because it doesn't mater what value we give it.
                        AddDeck(0);

                        // Give packs to open the right value
                        if (packsPerSets.Count == 0)
                        {
                            packsToOpen = 0;
                        }
                        else
                        {
                            packsToOpen = packsPerSets[packsPerSets.Count - 1].Value[j];
                        }

                        // Open packs until the deck is craftable
                        while (!GetIfCraftable())
                        {
                            packsToOpen++;
                        }

                        // Add cards to the memory
                        packsOpenedForCurrentDeck[i] += packsToOpen;
                        packsOpenedForAllDecks[i, j] = packsToOpen;
                    }

                    if (cheapestAmountOfPacks == packsOpenedForCurrentDeck[i])
                    {
                        danger = true;
                    }

                    // If the deck is cheaper than the current deck, make it the cheapest
                    if (cheapestAmountOfPacks > packsOpenedForCurrentDeck[i])
                    {
                        cheapestAmountOfPacks = packsOpenedForCurrentDeck[i];
                        cheapestIndex = i;

                        danger = false;
                    }
                }
                // If there is a tie between decks, inform us
                if (danger)
                {
                    Console.WriteLine("WARNING TIE WARNING TIE WARNING TIE WARNING TIE WARNING TIE WARNING TIE WARNING TIE WARNING TIE WARNING TIE WARNING TIE");

                    // Then show the decks that are tied with their pack values
                    for (int i = 0; i < packsOpenedForCurrentDeck.Length; i++)
                    {
                        if (packsOpenedForCurrentDeck[i] == cheapestAmountOfPacks)
                        {
                            Console.WriteLine("DECK: " + deckMemory[i] + " - PACKS: " + packsOpenedForCurrentDeck[i]);
                        }

                    }
                }
                // Print name of cheapest deck
                Console.WriteLine("The cheapest deck is " + deckMemory[cheapestIndex]);

                // Add decks that mid calculation would turn cheaper than pre calculated decks (HARD CODED)
                if (deckMemory[cheapestIndex] == "Template 1")
                {
                    deckMemory.Add("Template 2");
                }

                // Get all packs opened for the specific sets of the cheapest deck and print "Set/Packs opened"
                for (int i = 0; i < setMemory.Length; i++)
                {
                    Console.WriteLine("This many packs where opened for " + setMemory[i] + ": " + packsOpenedForAllDecks[cheapestIndex, i]);

                    packsOpenedForCheapestDeck[i] = packsOpenedForAllDecks[cheapestIndex, i];
                }

                // Add the result to packsPerSets and remove the craftable deck from the list as if we crafted it.
                packsPerSets.Add(new PacksForSetsDictionary(deckMemory[cheapestIndex], (int[])packsOpenedForCheapestDeck.Clone()));
                deckMemory.Remove(deckMemory[cheapestIndex]);

                Console.WriteLine();
            }
        }
        #endregion

        #region Pack management
        // Add cards to the collection
        static void AddCard(int rarityIndex, double card)
        {
            // CardPercentage is a card we've opened and want to insert in our collection. PreviousPercentage is a memory variable
            double cardPercentage = card;
            double previousPercentage;

            // In case of rare and mythic rare, add duplicate protection (see that function)
            if (cardPercentage > 0 && (rarityIndex == 2 || rarityIndex == 3))
            {
                AddFullCard(rarityIndex, cardPercentage);
            }
            else
            {
                for (int i = 0; i < maxDuplicates; i++)
                {
                    // 1 First, turn previousPercentage in the current one.
                    // 2 Then, for the current duplicate amount, get what the chances are to open a card we haven't had with this many duplicates
                    // 3 Devide this number with the total amount of cards in this rarity so we get a value between 1 and 0 (or thus a percentage).
                    // 4 Multiply this with the card we have *left over* and add the percentage.
                    previousPercentage = cardPercentage;
                    cardPercentage = ((cardsInSet[rarityIndex] - cardCopiesOwned[rarityIndex, i]) / cardsInSet[rarityIndex]) * cardPercentage;
                    cardCopiesOwned[rarityIndex, i] += cardPercentage;

                    // 5 The cardpercentage now becomes the chance we didn't open on this duplicate amount. The *left over*
                    cardPercentage = previousPercentage - cardPercentage;
                }

                // Simple vaultpoints addition. 5th duplications are turned into vaultpoints
                if (rarityIndex == 0)
                {
                    vaultPoints += cardPercentage;
                }
                else
                {
                    vaultPoints += cardPercentage * 3;
                }
            }
        }

        static void AddFullCard(int rarityIndex, double card)
        {
            double cardPercentage = card;
            double previousPercentage;

            for (int i = 0; i < maxDuplicates; i++)
            {
                // Pretty much the same except the numbers are decreased with the 4th duplicate amount of cards we've opened.
                // This is because now, the calculation works with higher chance numbers, BUT the 4th duplication will ALWAYS be a 100% as the substraction becomes 0
                previousPercentage = cardPercentage;
                cardPercentage = (((cardsInSet[rarityIndex] - cardCopiesOwned[rarityIndex, 3]) - (cardCopiesOwned[rarityIndex, i] - cardCopiesOwned[rarityIndex, 3])) / (cardsInSet[rarityIndex] - cardCopiesOwned[rarityIndex, 3])) * cardPercentage;
                cardCopiesOwned[rarityIndex, i] += cardPercentage;

                cardPercentage = previousPercentage - cardPercentage;
            }
        }
        #endregion
    }
}
